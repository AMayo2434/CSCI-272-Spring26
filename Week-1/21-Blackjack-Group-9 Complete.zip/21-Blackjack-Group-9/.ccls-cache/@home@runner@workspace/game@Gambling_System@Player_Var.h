#pragma once
#include <cstdlib>

extern int player_points, pl_risk, pl_round_score, new_number, turns_pl;
extern char player_input;
