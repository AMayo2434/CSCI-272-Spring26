#pragma once
#include <cstdlib>

extern int dl_round_score, turns, new_number_dl, dealer_hit_chance;
extern char cont;
