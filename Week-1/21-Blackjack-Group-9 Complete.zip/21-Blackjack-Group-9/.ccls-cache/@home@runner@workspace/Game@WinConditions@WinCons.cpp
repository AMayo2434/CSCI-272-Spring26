#include <iostream>
using namespace std;
#include <cstdlib>

#include "Player_Var.h"
#include "Dealer_Var.h"
// DEFINE VARIABLES (May rename)

int wincons() {
if (pl_round_score <= 21 && dl_round_score < pl_round_score)

{

  cout << "You won! Your final score is: " << pl_round_score;

  if (player_points == 100) {

    cout << "Congratulations! You won! Your final score is: 100!" << endl;  }

  if (player_points != 100)

   cout << "Play again?";

  // add the gambling system function to allow replay of the game with G-Syst.

}

 else if (player_points == 100 ) {
 cout << "Congratulations! You won! Your final score is: 100! Play again?" << endl;
}

  else if (player_points == 0 && pl_risk == 50) {



}

  else if (pl_round_score <= 21 && dl_round_score > pl_round_score){

    cout << "You lost! Your final score is: " << pl_round_score << " Play again?";  

    // add gambling system here, reset player point to 50, add the pl switch case here w/ gameplay. (ends out) FOLDER

  }

  else if (pl_round_score == dl_round_score) {

    cout << "It's a tie! Your final score is: " << pl_round_score << " Play again?";
  }

    else if (pl_round_score > 21 && dl_round_score <= 21)
    {

      cout << "You busted! Your final score is: " << pl_round_score << " Play again?";



    }

else if (pl_round_score > 21 &&  dl_round_score > 21) {

cout << "You both busted! Your final score is: " << pl_round_score <<  " Play again?";


}

  }
  


