#include <iostream>
using namespace std;
#include "../Gambling_System/Player_Var.h"

extern int player_points, pl_risk, pl_round_score, new_number, turns_pl;
extern char player_input;

int  player_gp() {

player_input = 0;

  while ((player_input != 'S' && player_input != 's') && (pl_round_score <= 21) {
          cout << "Press 'H' to hit or 'S' to stand:" << endl;
          cout << "Current score: " << pl_round_score << endl;

          cin >> player_input;
          cout << endl;

          switch (player_input) {

          case 'H':
          case 'h':
              new_number = 1 + rand() % 11;
              pl_round_score += new_number;

              cout << "Turn: " << ++turns_pl << endl;
              cout << endl;

              cout << "You chose to hit. Your new number is: " << new_number << endl;
              cout << endl;

              cout << "Your new score is: " << pl_round_score << " /21" << endl;
              cout << endl;

              if (pl_round_score > 21) {
                  cout << "BUST! Waiting for dealer to play..." << endl;
                  cout << endl;

                  return 1;   // <—— FIX: exits immediately so dealer can play
              }
              break;

          case 'S':
          case 's':
              cout << "Turns: " << ++turns_pl << endl;
              cout << endl;

              cout << "You chose to stand. Your final score is: "
                   << pl_round_score << " /21. The dealer will now play." << endl;
              cout << endl;

              return 1;   // <—— exit so dealer plays
          }
      }

      return 0;
  }
// Player gameplay