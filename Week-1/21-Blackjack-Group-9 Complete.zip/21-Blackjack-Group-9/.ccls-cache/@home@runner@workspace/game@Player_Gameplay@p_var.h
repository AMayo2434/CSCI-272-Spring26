extern int pl_round_score{0}, new_number{1 + rand() % 11}, turns_pl{1};

extern char  player_input{0};