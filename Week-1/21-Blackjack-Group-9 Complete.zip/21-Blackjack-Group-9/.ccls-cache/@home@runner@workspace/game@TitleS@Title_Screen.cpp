//Win conditions for the game
#include <iostream>
using namespace std;
#include "Proceed_Var.h"

// Define global variables for title screen
char title_choice = 0, startgame = 0;
char play_again = 0;

int player_gp();
int g_system();
int dealer();
int wincons();

int title_screen() {

while (title_choice != 'Q' && title_choice != 'q') {

  cout << endl;
  cout << endl;
  
  cout << "**21 Blackjack**" << endl;

  cout << endl;
  cout << endl;

cout << "\nPress any key to continue...\n" << endl;

  cout << endl;
  cout << endl;
  
cin >> startgame;

cout << "*Play*\t *Rules*\t*Quit*\t*Credits*" << endl;

  cout << endl;
  cout << endl;

cout << "Press 'P' to play, 'R' for rules, 'Q' to quit, or 'C' for credits:" << endl;
  cout << endl;
  cout << endl;
cin >> title_choice;

switch (title_choice) {

  case 'Q': cout << "Thank you for playing!";
    break;

  case 'q': cout << "Thank you for playing!";
    break;

  case 'P':  play_again = 'Y';

  while (play_again == 'Y' || play_again == 'y') {
    g_system();
    player_gp();
    dealer();
    wincons();

    cout << endl;
    cout << "Would you like to play again? (Y/N): " << endl;
    cin >> play_again;
  }
  case 'p': 
    play_again = 'Y';
    
    while (play_again == 'Y' || play_again == 'y') {
      g_system();
      player_gp();
      dealer();
      wincons();
      
      cout << endl;
      cout << "Would you like to play again? (Y/N): " << endl;
      cin >> play_again;
    }
    
    title_choice = 'Q';
    break;

  case 'R': cout << "The player will play against a dealer. At the beginning of each round, the player may choose how much they will choose to 'gamble'. This will be subtracted from the player's base score of 50. Once the player has chosen how much they will gamble, the round will begin. To play a single round, spend 50 points. The game ends when the player has 0 points. You win when you have 100 points. \n\n The player will begin with a round score of 0. The player will be able to choose to hit or stand. If the player hits, they will be assigned a number between 1 and 11. If the player stands, the dealer will then proceed to play. The player with the highest score without going over 21 wins.";
    break;

  case 'r': cout << "The player will play against a dealer. At the beginning of each round, the player may choose how much they will choose to 'gamble'. This will be subtracted from the player's base score of 50. Once the player has chosen how much they will gamble, the round will begin. To play a single round, spend 50 points. The game ends when the player has 0 points. You win when you have 100 points. \n\n The player will begin with a round score of 0. The player will be able to choose to hit or stand. If the player hits, they will be assigned a number between 1 and 11. If the player stands, the dealer will then proceed to play. The player with the highest score without going over 21 wins.";
    break;

  case 'C': cout << "Created by: Alicia Mayo for CSCI 271. Coded in replit with C++.";
    break;

  case 'c': cout << "Created by: Alicia Mayo for CSCI 271. Coded in replit with C++.";
    break;

  default: 
    title_choice = 0;
    break;
}

  }
  return 0;
}