#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

#include "Dealer_Var.h"

// Define global variables for dealer
int dl_round_score = 0, turns = 0, new_number_dl = 1 + rand() % 11, dealer_hit_chance = 0;
char cont = 0;

int dealer() {

    dl_round_score = 0;
    turns = 0;

    while (dl_round_score < 17) {
// Guaranteed hit when 16 or lower
        
        cout << "Turn: " << ++turns << endl;
        cout << endl;

        new_number_dl = 1 + rand() % 11;
        dl_round_score += new_number_dl;

        cout << "\tDealer hits: " << new_number_dl << endl;
        cout << endl;
        cout << "\tNew score: " << dl_round_score << endl;
        cout << endl;
    }

    // Stand chance when 17–18
    // Stand / hit logic for 17–21
    if (dl_round_score <= 18) {

        cout << "Turn: " << ++turns << endl;
        cout << endl;

        dealer_hit_chance = 1 + rand() % 100;

        if (dealer_hit_chance <= 25) {   // 25% hit chance at 17–18
            new_number_dl = 1 + rand() % 11;
            dl_round_score += new_number_dl;

            cout << "\tDealer hits: " << new_number_dl << endl;
            cout << endl;
            cout << "\tNew score: " << dl_round_score << endl;
            cout << endl;
        }
        else {
            cout << "\tDealer stands at " << dl_round_score << endl;
            cout << endl;
        }
    }

    // Dealer has 19: 3% hit chance
    else if (dl_round_score == 19) {

        cout << "Turn: " << ++turns << endl;
        cout << endl;

        dealer_hit_chance = 1 + rand() % 100;

        if (dealer_hit_chance <= 3) {   // 3% hit chance at 19
            new_number_dl = 1 + rand() % 11;
            dl_round_score += new_number_dl;

            cout << "\tDealer hits: " << new_number_dl << endl;
            cout << endl;
            cout << "\tNew score: " << dl_round_score << endl;
            cout << endl;
        }
        else {
            cout << "\tDealer stands at " << dl_round_score << endl;
            cout << endl;
        }
    }

    // Dealer has 20: 2% hit chance
    else if (dl_round_score == 20) {

        cout << "Turn: " << ++turns << endl;
        cout << endl;

        dealer_hit_chance = 1 + rand() % 100;

        if (dealer_hit_chance <= 2) {   // 2% hit chance at 20
            new_number_dl = 1 + rand() % 11;
            dl_round_score += new_number_dl;

            cout << "\tDealer hits: " << new_number_dl << endl;
            cout << endl;
            cout << "\tNew score: " << dl_round_score << endl;
            cout << endl;
        }
        else {
            cout << "\tDealer stands at " << dl_round_score << endl;
            cout << endl;
        }
    }

    // Dealer has 21, will always stands
    else if (dl_round_score == 21) {

        cout << "Turn: " << ++turns << endl;
        cout << endl;

        cout << "\tDealer stands at " << dl_round_score << endl;
        cout << endl;
    }


    return dl_round_score;
}
