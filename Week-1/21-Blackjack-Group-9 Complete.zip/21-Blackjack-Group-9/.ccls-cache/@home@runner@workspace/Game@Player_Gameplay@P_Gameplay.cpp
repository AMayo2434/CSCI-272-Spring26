#include <iostream>
using namespace std;
#include "Player_Var.h"

int  player_gp() {

while (player_input != S || player_input != s) {
  cout << "Press 'H' to hit or 'S' to stand:" << endl;
  cin >> player_input;
  cout << endl;

  cout << "Current score: " << pl_round_score;

switch (player_input) {

  case 'H': if (pl_round_score <= 21) {

    cout << "Turn: " << turns_pl << endl;
    ++turns_pl;

    cout << "You chose to hit. Your new number is: " << new_number << endl;
    cout << endl;

    cout << "Your new score is: " << pl_round_score + new_number << " /21" << endl;}

    else if (pl_round_score > 21) { 
      cout << "Turn: " << turns_pl << endl;
      ++turns_pl;

  cout << "BUST! Waiting for dealer to play..." << endl;}
  break;

    case 'h': if (pl_round_score <= 21) {

    cout << "Turn: " << turns_pl << endl;
    ++turns_pl;

    cout << "You chose to hit. Your new number is: " << new_number << endl;
    cout << endl;
    cout << endl;

    cout << "Your new score is: " << pl_round_score + new_number << " /21" << endl;}

    else if (pl_round_score > 21) { 
      cout << "Turn: " << turns_pl << endl;
      ++turns_pl;

  cout << "BUST! Waiting for dealer to play..." << endl;}
  break;

  case 'S' : cout << "You chose to stand. Your final score is: " << pl_round_score << " /21." << "The dealer will now play." << endl;
  break;

   case 's' :  cout << "You chose to stand. Your final score is: " << pl_round_score << " /21." << "The dealer will now play." << endl;
   break;

  default: cout << "Please enter a valid input." << endl;
  break;
}
  }
  }
// Player gameplay