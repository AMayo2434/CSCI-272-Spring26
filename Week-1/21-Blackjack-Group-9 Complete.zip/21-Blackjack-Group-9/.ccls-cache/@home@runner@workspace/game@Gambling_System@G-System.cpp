// gambling system, end of game round will determine if points are regained or lost 

#include <iostream>
using namespace std;
#include "Player_Var.h"

// Define global variables for this file
int player_points = 50, pl_risk = 0, pl_round_score = 0, new_number = 1 + rand() % 11, turns_pl = 0;
char player_input = 0;

int g_system() {

pl_round_score = 0;
turns_pl = 0;

cout << "Please choose how many points you would like to gamble: " << endl; 

  if (player_points != 0) { // As long as player points != 0, run gambling system. 

  cin >> pl_risk;

    if (pl_risk > player_points) {
      cout << "You do not have enough points to gamble that amount. Please enter a valid amount." << endl;
      cin >> pl_risk;}
    }

  else if (player_points == 0) {

    cout << "You have no points left. Please restart the game." << endl;
  }
  
  player_points = player_points - pl_risk;

cout << "Your now have: " << player_points << " points." << "You have: " << pl_risk << " points on the line." << endl;
  cout << endl;
  return 0;
}
