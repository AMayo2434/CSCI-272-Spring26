#include <iostream>
using namespace std;
#include <cstdlib>

#include "DealerT.cpp"
#include "G-System.cpp"
#include "P_Gameplay.cpp"
#include "Title_Screen.cpp"
#include "WinCons.cpp"

int main() { 

  // Title Screen

  int title_screen();

  // G-System before the game begins to confirm if the player has enough points. Use all points to go "All In" to play a single round.

  // Player gameplay continues until the player hits stand or busts.

  
  // Dealer gameplay continues until the dealer hits stand or busts.


  // Win conditions determine the winner of the round and awards points to the player or subtracts points from the player.


// Adding option to
  
  
  }

  









  
   