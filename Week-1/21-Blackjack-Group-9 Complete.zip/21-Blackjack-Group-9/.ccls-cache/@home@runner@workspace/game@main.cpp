#include <iostream>
using namespace std;
#include <cstdlib>
#include <ctime>

int title_screen();
int g_system();
int player_gp();
int wincons();
int dealer();

int main() { 

  srand(time(0));
  // Title Screen
  title_screen();

  // G-System before the game begins to confirm if the player has enough points. Use all points to go "All In" to play a single round.
  g_system();

  // Player gameplay continues until the player hits stand or busts.
  player_gp();
  
  // Dealer gameplay continues until the dealer hits stand or busts.
  dealer();
  // Add dealer gameplay call here

  // Win conditions determine the winner of the round and awards points to the player or subtracts points from the player.
  wincons();

  return 0;
}

  









  
   