#include <iostream>
using namespace std;
#include <cstdlib>

#include "../Gambling_System/Player_Var.h"
#include "../Dealer/Dealer_Var.h"

int wincons() {

    // --- PLAYER WINS: Player score <= 21 and dealer score < player score ---
    if (pl_round_score <= 21 && dl_round_score < pl_round_score)
    {
        cout << "You won the round! Your final score is: " << pl_round_score << endl;

         cout << endl;
        // Add double the gamble amount to player points
        player_points += (pl_risk * 2);

        cout << "Your new point total: " << player_points << endl;
            cout << endl;
       
    }

    // --- PLAYER WINS: Player <= 21 and dealer busts ---
    else if (pl_round_score <= 21 && dl_round_score > 21)
    {
        cout << "Dealer busted at " << dl_round_score << "! You win the round! Your score: " << pl_round_score << endl;
        cout << endl;

        // Add double the gamble amount to player points
        player_points += (pl_risk * 2);

        cout << "Your new point total: " << player_points << endl;
            cout << endl;
    }

    // --- DEALER WINS: Player <= 21 and dealer score > player score ---
    else if (pl_round_score <= 21 && dl_round_score <= 21 && dl_round_score > pl_round_score)
    {
        cout << "You lost the round! Your final score is: " << pl_round_score << endl;
            cout << endl;
        // Deduct points
        player_points -= pl_risk;

        cout << "Your new point total: " << player_points << endl;
            cout << endl;
    }

    // --- TIE ---
    else if (pl_round_score == dl_round_score && pl_round_score <= 21)
    {
        cout << "It's a tie! Your final score is: " << pl_round_score << endl;
            cout << endl;
        cout << "No points gained or lost." << endl;
            cout << endl;
        cout << "Your point total: " << player_points << endl;
            cout << endl;
    }

    // --- PLAYER BUSTS (dealer doesn't) ---
    else if (pl_round_score > 21 && dl_round_score <= 21)
    {
        cout << "You busted! Final score: " << pl_round_score << endl;
            cout << endl;
        player_points -= pl_risk;

        cout << "Your new point total: " << player_points << endl;
            cout << endl;
    }

    // --- BOTH BUST ---
    else if (pl_round_score > 21 && dl_round_score > 21)
    {
        cout << "You both busted! No points gained or lost." << endl;
            cout << endl;
        cout << "Your point total: " << player_points << endl;
            cout << endl;
       
    }

    // Check if player has 0 points (lost the game) AFTER all outcomes
    if (player_points <= 0) {
        cout << "You've run out of points! Game over." << endl;
        cout << endl;
        return 0;
    }

    // Check if player reached 100+ points (won the game) AFTER all outcomes
    if (player_points >= 100) {
        cout << "Congratulations! You've reached 100 points and won the game!" << endl;
        cout << endl;
        return 0;
    }

    return 0;
}


