#pragma once

extern char title_choice, startgame;
